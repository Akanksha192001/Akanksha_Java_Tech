package com.hexaware.java8examples.functionalinterfacetask;

public class LambdaExpressionExamp {

	public static void main(String[] args) {
		Message mes = () -> System.out.println("Quotation method implemented using Lambda Expression");
		mes.quotation();

	}

}
