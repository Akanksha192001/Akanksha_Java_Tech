package com.hexaware.java8examples.functionalinterfacetask;

@FunctionalInterface
public interface Message {
	void quotation();//SAM

}
